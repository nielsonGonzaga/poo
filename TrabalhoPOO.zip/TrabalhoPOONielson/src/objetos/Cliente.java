package objetos;

public class Cliente {

    private String nomeCliente;
    private String email;
    
    public void comprar(){
        System.out.println("Comprando...");
    }
    
    public void alugar(){
        System.out.println("Alugando...");
    }
   
    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
