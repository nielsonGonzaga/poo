package principal;

import objetos.Carro;
import objetos.Cliente;
import objetos.Usuario;

public class Main {
    public static void main(String[] args) {
        Cliente cliente = new Cliente();
        Usuario usuario = new Usuario();
        Carro carro = new Carro();
        
        cliente.alugar();
        cliente.comprar();
        usuario.acessar();
        usuario.usar();
        carro.andar();
        carro.ligarFarois();
        
    }
}
