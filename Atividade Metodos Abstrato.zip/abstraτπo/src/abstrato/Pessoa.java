package abstrato;

public abstract class Pessoa {
    public void andar(){
        System.out.println("Andando...");
    }
}
