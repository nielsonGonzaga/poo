package abstrato;

public abstract class Funcionario {
    public void trabalhar(){
        System.out.println("Trabalhando...");
    }
}
