package abstrato;

public abstract class Construcao {
    public void construir(){
        System.out.println("Construindo...");
    }
}
