package principal;

import concreto.Construcao1;
import concreto.Construcao2;
import concreto.Construcao3;
import concreto.Funcionario1;
import concreto.Funcionario2;
import concreto.Funcionario3;
import concreto.Pessoa1;
import concreto.Pessoa2;
import concreto.Pessoa3;

public class Principal {

    public static void main(String[] args) {
        Pessoa1 p1 = new Pessoa1();
        Pessoa2 p2 = new Pessoa2();
        Pessoa3 p3 = new Pessoa3();
        Funcionario1 f1 = new Funcionario1();
        Funcionario2 f2 = new Funcionario2();
        Funcionario3 f3 = new Funcionario3();
        Construcao1 c1 = new Construcao1();
        Construcao2 c2 = new Construcao2();
        Construcao3 c3 = new Construcao3();
        
        p1.andar();
        p2.andar();
        p3.andar();
        f1.trabalhar();
        f2.trabalhar();
        f3.trabalhar();
        c1.construir();
        c2.construir();
        c3.construir();
    }
    
}
