package concreto;

import abstrato.Pessoa;

public class Pessoa1 extends Pessoa {
    
}
