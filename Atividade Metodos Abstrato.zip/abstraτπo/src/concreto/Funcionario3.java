package concreto;

import abstrato.Funcionario;

public class Funcionario3 extends Funcionario {
    
}
