package concreto;

import abstrato.Funcionario;

public class Funcionario1 extends Funcionario {
    
}
