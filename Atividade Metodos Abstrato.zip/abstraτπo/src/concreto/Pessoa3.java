package concreto;

import abstrato.Pessoa;

public class Pessoa3 extends Pessoa {
    
}
