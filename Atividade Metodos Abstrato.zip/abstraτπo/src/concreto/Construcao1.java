package concreto;

import abstrato.Construcao;

public class Construcao1 extends Construcao {
    
}
