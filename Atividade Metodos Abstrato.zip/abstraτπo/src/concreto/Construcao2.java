package concreto;

import abstrato.Construcao;

public class Construcao2 extends Construcao {
    
}
