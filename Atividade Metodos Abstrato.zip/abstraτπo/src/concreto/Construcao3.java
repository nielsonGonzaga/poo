package concreto;

import abstrato.Construcao;

public class Construcao3 extends Construcao {
    
}
