package concreto;

import abstrato.Pessoa;

public class Pessoa2 extends Pessoa {
    
}
