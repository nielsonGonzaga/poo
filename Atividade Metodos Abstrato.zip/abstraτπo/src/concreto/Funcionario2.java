package concreto;

import abstrato.Funcionario;

public class Funcionario2 extends Funcionario {
    
}
